# LOG635-LABO1-EQ5

Reconaissance d'image avec python
